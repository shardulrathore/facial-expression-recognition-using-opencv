# Emotion_Detection_CNN

Data Set Link - https://www.kaggle.com/jonathanoheix/face-expression-recognition-dataset
